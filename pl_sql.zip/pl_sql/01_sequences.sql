-- Création de la séquence pour log
-- =======================================
CREATE SEQUENCE LOG_ACTIONS_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;
/