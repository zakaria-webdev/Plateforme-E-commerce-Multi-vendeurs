-- =======================================
-- Package Body
-- =======================================

CREATE OR REPLACE PACKAGE BODY shop_pkg AS

    -- =======================================
    -- Fonction pour appliquer coupon
    -- =======================================
    FUNCTION appliquer_coupon(
        p_id_comm IN NUMBER,
        p_code_coupon IN VARCHAR2
    ) RETURN NUMBER
    IS
        v_total NUMBER;
        v_taux NUMBER;
        v_date_valid DATE;
    BEGIN
        -- Récupérer le total de la commande
        SELECT SUM(prix_unitaire * quantite)
        INTO v_total
        FROM LIGNE_COMMANDE
        WHERE id_comm = p_id_comm;

        -- Vérifier si le coupon existe et est valide
        SELECT taux, date_validite
        INTO v_taux, v_date_valid
        FROM COUPON
        WHERE code = p_code_coupon;

        IF v_date_valid < SYSDATE THEN
            RAISE_APPLICATION_ERROR(-20010, 'Coupon expiré');
        END IF;
        -- verificatio de taux 
        IF v_taux < 0 OR v_taux > 100 THEN
            RAISE_APPLICATION_ERROR(-20012, 'Taux de coupon invalide');
        END IF;

        -- Calculer le montant après remise
        v_total := v_total * (1 - v_taux/100);

        RETURN v_total;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20011, 'Coupon invalide');
    END appliquer_coupon;

    -- =======================================
    -- Modification de la procédure de paiement pour intégrer le coupon
    -- =======================================
    PROCEDURE prcd_statu_commd (
        p_id_comm IN NUMBER,
        p_action  IN VARCHAR2,
        p_code_coupon IN VARCHAR2 DEFAULT NULL
    )
    IS
        v_statut COMMANDE.statut%TYPE;
        v_total NUMBER;
        v_client_id NUMBER;
    BEGIN
        -- Verrouiller la commande
        SELECT statut, id_cli INTO v_statut, v_client_id
        FROM COMMANDE
        WHERE id_comm = p_id_comm
        FOR UPDATE;

        -- Vérifier l'action
        IF p_action = 'pay' THEN
            IF v_statut = 'Pending' THEN

                -- Si coupon fourni, recalculer le total
                IF p_code_coupon IS NOT NULL THEN
                    v_total := appliquer_coupon(p_id_comm, p_code_coupon);
                ELSE
                    SELECT SUM(prix_unitaire * quantite) INTO v_total
                    FROM LIGNE_COMMANDE
                    WHERE id_comm = p_id_comm;
                END IF;

                -- Mettre à jour le statut et le montant total
                UPDATE COMMANDE
                SET statut = 'Paid',
                    montant_total = v_total
                WHERE id_comm = p_id_comm;
                
                -- Log de paiement
                log_action_p('PAYMENT', v_client_id,
                    'Commande ' || p_id_comm || ' payée, total: ' || v_total);

            ELSE
                RAISE_APPLICATION_ERROR(-20001, 'Impossible de payer : statut actuel = ' || v_statut);
            END IF;

        ELSIF p_action = 'ship' THEN
            IF v_statut = 'Paid' THEN
                UPDATE COMMANDE
                SET statut = 'Shipped'
                WHERE id_comm = p_id_comm;
                
                -- Log d'expédition
                log_action_p('SHIPMENT', v_client_id,
                    'Commande ' || p_id_comm || ' expédiée');
                    
            ELSE
                RAISE_APPLICATION_ERROR(-20002, 'Impossible d’expédier : statut actuel = ' || v_statut);
            END IF;

        ELSE
            RAISE_APPLICATION_ERROR(-20003, 'Action inconnue : ' || p_action);
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20004, 'Commande introuvable : ' || p_id_comm);
    END prcd_statu_commd;


    -- =======================================
    -- Procédure de traitement complet de commande
    -- =======================================
    PROCEDURE traiter_commande_complete (
        p_id_comm     IN NUMBER,
        p_client_id   IN NUMBER,
        p_lignes      IN SYS.ODCINUMBERLIST,    -- liste id_prod
        p_quantites   IN SYS.ODCINUMBERLIST,    --Quantités approuvées 
        p_coupon_code IN VARCHAR2 DEFAULT NULL   --optional: coupon
    )
    IS
        v_total        NUMBER;
        v_stock_rest   PRODUIT.quantite_stock%TYPE;
    BEGIN
        -- Créer une commande
        INSERT INTO COMMANDE(id_comm, id_cli, statut, date_commande)
        VALUES (p_id_comm, p_client_id, 'Pending', SYSDATE);

        -- Créer  SAVEPOINT après avoir créé une commande
        SAVEPOINT sp_commande_creee;

    -- Traitement de chaque ligne
        FOR i IN 1 .. p_lignes.COUNT LOOP
            BEGIN
                -- Apporter le stock actuel
                SELECT quantite_stock
                INTO v_stock_rest
                FROM PRODUIT
                WHERE id_prod = p_lignes(i)
                FOR UPDATE;

            -- Vérifier le stock
                IF v_stock_rest < p_quantites(i) THEN
                    ROLLBACK TO sp_commande_creee;
                    RAISE_APPLICATION_ERROR(-20001, 'Stock insuffisant pour le produit ' || p_lignes(i));
                END IF;

                -- Mise à jour des stocks
                UPDATE PRODUIT
                SET quantite_stock = quantite_stock - p_quantites(i)
                WHERE id_prod = p_lignes(i);

                --Enregistrement du processus dans log_action
                log_action_p('MODIFICATION_STOCK', p_client_id,
                    'Produit ' || p_lignes(i) || ' mis à jour, nouvelle quantité: ' || (v_stock_rest - p_quantites(i)));

                ---- Ajouter ligne_commande
                INSERT INTO LIGNE_COMMANDE(id_comm, id_prod, quantite, prix_unitaire)
                SELECT p_id_comm, p_lignes(i), p_quantites(i), prix
                FROM PRODUIT
                WHERE id_prod = p_lignes(i);

            EXCEPTION
                WHEN OTHERS THEN
                    -- rollback complet
                    ROLLBACK TO sp_commande_creee;
                    RAISE_APPLICATION_ERROR(-20002, 'Erreur lors de l''ajout de la ligne: ' || SQLERRM);
            END;
        END LOOP;

        -- Paiement avec coupon si disponible
        BEGIN
            IF p_coupon_code IS NOT NULL THEN
                v_total := appliquer_coupon(p_id_comm, p_coupon_code);
            ELSE
                SELECT SUM(prix_unitaire * quantite)
                INTO v_total
                FROM LIGNE_COMMANDE
                WHERE id_comm = p_id_comm;
            END IF;
        --remise solde de client
            UPDATE CLIENT
            SET solde = solde - v_total
            WHERE id_cli = p_client_id;

            ---- Mettre à jour statut et le total des commandes
            UPDATE COMMANDE
            SET statut = 'Paid',
                montant_total = v_total
            WHERE id_comm = p_id_comm;

            ---- Enregistrement du paiement dans log_action
        log_action_p('PAYMENT', p_client_id,
                'Commande ' || p_id_comm || ' payée, total: ' || v_total);

        EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK TO sp_commande_creee;
                RAISE_APPLICATION_ERROR(-20003, 'Erreur lors du paiement: ' || SQLERRM);
        END;

        -- Tout est réussi → commit
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            --Toute erreur inattendue → ROLLBACK complète
            ROLLBACK;
            RAISE;
    END traiter_commande_complete;


    -- =======================================
    -- Procédure de remboursement
    -- =======================================
    PROCEDURE prcd_remboursement (
        p_id_comm         IN NUMBER,
        p_client_id       IN NUMBER,
        p_quantites_remb  IN SYS.ODCINUMBERLIST DEFAULT NULL, -- optional: partial refund par produit
        p_total_rembourse IN NUMBER DEFAULT NULL             -- optional: total montant remboursé
    )
    IS
        CURSOR cur_lignes IS
            SELECT id_prod, quantite, prix_unitaire
            FROM LIGNE_COMMANDE
            WHERE id_comm = p_id_comm
            FOR UPDATE;

        v_montant NUMBER := 0;
    BEGIN
        -- Loop sur chaque ligne de commande
        FOR i IN cur_lignes LOOP
            DECLARE
                v_remb_quant NUMBER := i.quantite; -- default full quantity
            BEGIN
                -- si remboursement partiel fourni, utiliser la quantité correspondante
                IF p_quantites_remb IS NOT NULL THEN
                    v_remb_quant := p_quantites_remb(i.id_prod); 
                    IF v_remb_quant > i.quantite THEN
                        RAISE_APPLICATION_ERROR(-20001, 'Quantité remboursement > quantité commandée pour produit ' || i.id_prod);
                    END IF;
                END IF;

                -- mise à jour du stock
                UPDATE PRODUIT
                SET quantite_stock = quantite_stock + v_remb_quant
                WHERE id_prod = i.id_prod;

                -- calcul montant
                v_montant := v_montant + (i.prix_unitaire * v_remb_quant);

                -- mise à jour ligne_commande
                UPDATE LIGNE_COMMANDE
                SET quantite = quantite - v_remb_quant
                WHERE id_comm = p_id_comm
                AND id_prod = i.id_prod;

                -- supprimer ligne si quantité devient 0
                DELETE FROM LIGNE_COMMANDE
                WHERE id_comm = p_id_comm
                AND id_prod = i.id_prod
                AND quantite = 0;

                -- log
                log_action_p('REMBOURSEMENT', p_client_id,
                    'Produit ' || i.id_prod || ' remboursé, quantité: ' || v_remb_quant);

            END;
        END LOOP;

        -- si montant total remboursé fourni, on l'utilise
        IF p_total_rembourse IS NOT NULL THEN
            v_montant := p_total_rembourse;
        END IF;

        -- mise à jour solde client
        UPDATE CLIENT
        SET solde = solde + v_montant
        WHERE id_cli = p_client_id;

        -- mise à jour statut commande si toutes lignes remboursées
        DECLARE
            v_remaining NUMBER;
        BEGIN
            SELECT SUM(quantite) INTO v_remaining
            FROM LIGNE_COMMANDE
            WHERE id_comm = p_id_comm;

            IF v_remaining IS NULL OR v_remaining = 0 THEN
                UPDATE COMMANDE
                SET statut = 'Remboursée'
                WHERE id_comm = p_id_comm;
            ELSE
                UPDATE COMMANDE
                SET statut = 'Partiellement remboursée'
                WHERE id_comm = p_id_comm;
            END IF;
        END;

        -- commit transaction
        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END prcd_remboursement ;
    
END shop_pkg;
/

