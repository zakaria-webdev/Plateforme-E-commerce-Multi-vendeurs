-- =======================================
-- Trigger pour gérer le stock
-- =======================================
CREATE OR REPLACE TRIGGER trg_gestion_stock
BEFORE INSERT OR UPDATE ON LIGNE_COMMANDE
FOR EACH ROW
DECLARE
    v_stock_rest PRODUIT.quantite_stock%TYPE;
    v_user COMMANDE.id_cli%TYPE;
BEGIN
    -- 1. Vérifier le stock actuel du produit et verrouiller la ligne
    SELECT quantite_stock
    INTO v_stock_rest
    FROM PRODUIT
    WHERE id_prod = :NEW.id_prod
    FOR UPDATE;

    -- 2. Vérifier si la quantité demandée est supérieure au stock disponible
    IF v_stock_rest < :NEW.quantite THEN
        RAISE_APPLICATION_ERROR(
            -20001, 
            'Stock insuffisant pour le produit ' || :NEW.id_prod
        );
    END IF;

    -- 3. Décrémenter le stock
    UPDATE PRODUIT
    SET quantite_stock = quantite_stock - :NEW.quantite
    WHERE id_prod = :NEW.id_prod;

    -- 4. Vérifier si le stock devient négatif après l'opération
    IF (v_stock_rest - :NEW.quantite) < 0 THEN
        RAISE_APPLICATION_ERROR(
            -20002, 
            'Erreur : Stock négatif détecté pour le produit ' || :NEW.id_prod
        );
    END IF;

    -- Optionnel : ajouter un log (si id_comm existe)
    IF :NEW.id_comm IS NOT NULL THEN
        BEGIN
            SELECT id_cli INTO v_user FROM COMMANDE WHERE id_comm = :NEW.id_comm;
            log_action_p('MODIFICATION_STOCK', v_user, 
                'Produit ' || :NEW.id_prod || ' mis à jour, nouvelle quantité: ' || (v_stock_rest - :NEW.quantite));
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                NULL; -- ignorer si commande non trouvée
        END;
    END IF;

END;
/