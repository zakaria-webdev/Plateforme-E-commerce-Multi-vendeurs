-- =======================================
-- Procédure autonome pour logging
-- =======================================

CREATE OR REPLACE PROCEDURE log_action_p(
  p_action_type VARCHAR2,
  p_user_id     NUMBER,
  p_details     VARCHAR2
) AS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO LOG_ACTIONS (id_log_action, action_type, user_id, date_action, details)
  VALUES (LOG_ACTIONS_SEQ.NEXTVAL, p_action_type, p_user_id, SYSTIMESTAMP, p_details);
  
  COMMIT;
  
 EXCEPTION
    WHEN OTHERS THEN
        -- Ignorer erreur de log pour ne pas casser transaction principale
        NULL;

END log_action_p;
/