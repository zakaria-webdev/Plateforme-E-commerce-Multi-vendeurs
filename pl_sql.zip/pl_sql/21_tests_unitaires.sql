-- =======================================
-- Tests procedures et fonctions
-- =======================================

-- Exemple: créer une commande et appliquer coupon
DECLARE
    v_lignes SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1,2);
    v_quantites SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(3,1);
BEGIN
    shop_pkg.traiter_commande_complete(1001, 1, v_lignes, v_quantites, 'COUPON10');
END;
/
