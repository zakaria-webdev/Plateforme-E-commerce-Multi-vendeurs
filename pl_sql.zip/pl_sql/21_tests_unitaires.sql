-- =======================================
-- Tests procedures et fonctions du package SHOP_PKG
-- =======================================

SET SERVEROUTPUT ON;

-- =======================================
-- Test 1: Créer une commande complète avec coupon
-- =======================================
DECLARE
    v_lignes SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1001,2001);
    v_quantites SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(2,1);
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 1: Créer commande avec coupon ---');
    shop_pkg.traiter_commande_complete(
        p_id_comm     => 6002,
        p_client_id   => 101,
        p_lignes      => v_lignes,
        p_quantites   => v_quantites,
        p_coupon_code => 'BIENVENUE10'
    );
    DBMS_OUTPUT.PUT_LINE('Commande 6001 créée avec succès pour client 101.');
   
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 1: ' || SQLERRM);
END;
/
 
-- =======================================
-- Test 2: Appliquer coupon directement via fonction
-- =======================================
SET SERVEROUTPUT ON;
DECLARE
    v_total NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 2: Appliquer coupon ---');
    v_total := shop_pkg.appliquer_coupon(501, 'SUMMER25');
    DBMS_OUTPUT.PUT_LINE('Montant total après coupon: ' || v_total);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 2: ' || SQLERRM);
END;
/

-- =======================================
-- Test 3: Paiement d'une commande existante
-- =======================================
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 3: Paiement commande ---');
    shop_pkg.prcd_statu_commd(
        p_id_comm     => 503,
        p_action      => 'pay',
        p_code_coupon => 'FIDELITE15'
    );
    DBMS_OUTPUT.PUT_LINE('Commande 503 payée avec succès.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 3: ' || SQLERRM);
END;
/

-- =======================================
-- Test 4: Remboursement partiel d'une commande
-- =======================================
DECLARE
    v_quant_remb SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1,0); -- id_prod => quantité remboursée
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 4: Remboursement partiel ---');
    shop_pkg.prcd_remboursement(
        p_id_comm        => 501,
        p_client_id      => 101,
        p_quantites_remb => v_quant_remb
    );
    DBMS_OUTPUT.PUT_LINE('Remboursement partiel effectué pour commande 501.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 4: ' || SQLERRM);
END;
/

-- =======================================
-- Test 5: Vérifier gestion stock et logs
-- =======================================
DECLARE
    v_stock PRODUIT.quantite_stock%TYPE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 5: Vérification stock produit 1001 ---');
    SELECT quantite_stock INTO v_stock FROM PRODUIT WHERE id_prod = 1001;
    DBMS_OUTPUT.PUT_LINE('Stock actuel produit 1001: ' || v_stock);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 5: ' || SQLERRM);
END;
/

-- =======================================
-- Test 6: Essai de paiement invalide
-- =======================================
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 6: Paiement invalide ---');
    shop_pkg.prcd_statu_commd(
        p_id_comm => 505, -- Commande annulée
        p_action  => 'pay'
    );
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 6 attendue: ' || SQLERRM);
END;
/

-- =======================================
-- Test 7: Créer commande sans coupon
-- =======================================
DECLARE
    v_lignes SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(2002, 3001);
    v_quantites SYS.ODCINUMBERLIST := SYS.ODCINUMBERLIST(1, 2);
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Test 7: Créer commande sans coupon ---');
    shop_pkg.traiter_commande_complete(
        p_id_comm     => 6002,
        p_client_id   => 102,
        p_lignes      => v_lignes,
        p_quantites   => v_quantites
    );
    DBMS_OUTPUT.PUT_LINE('Commande 6002 créée avec succès pour client 102.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erreur Test 7: ' || SQLERRM);
END;
/





