-- =======================================
-- Package specification
-- =======================================

CREATE OR REPLACE PACKAGE shop_pkg AS

    -- Fonction pour appliquer coupon
    FUNCTION appliquer_coupon(
        p_id_comm IN NUMBER,
        p_code_coupon IN VARCHAR2
    ) RETURN NUMBER;

    -- Procédures principales
    PROCEDURE prcd_statu_commd(
        p_id_comm IN NUMBER,
        p_action IN VARCHAR2,
        p_code_coupon IN VARCHAR2 DEFAULT NULL
    );

    PROCEDURE traiter_commande_complete(
        p_id_comm IN NUMBER,
        p_client_id IN NUMBER,
        p_lignes IN SYS.ODCINUMBERLIST,
        p_quantites IN SYS.ODCINUMBERLIST,
        p_coupon_code IN VARCHAR2 DEFAULT NULL
    );

    PROCEDURE prcd_remboursement(
        p_id_comm IN NUMBER,
        p_client_id IN NUMBER,
        p_quantites_remb IN SYS.ODCINUMBERLIST DEFAULT NULL,
        p_total_rembourse IN NUMBER DEFAULT NULL
    );

END shop_pkg;
/
